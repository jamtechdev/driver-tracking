/**
 * Google Maps Configuration
 */

import { env } from './env';

/**
 * Check if Google Maps API key is valid
 */
export const isMapsApiKeyValid = (): boolean => {
  const apiKey = env.GOOGLE_MAPS_API_KEY;
  return (
    !!apiKey &&
    apiKey.trim() !== '' &&
    apiKey !== 'YOUR_GOOGLE_MAPS_API_KEY' &&
    apiKey.length > 20 // Basic validation - real API keys are longer
  );
};

/**
 * Check if maps are available for use
 */
export const isMapsAvailable = (): boolean => {
  return isMapsApiKeyValid();
};

export const MAPS_CONFIG = {
  API_KEY: env.GOOGLE_MAPS_API_KEY,
  IS_AVAILABLE: isMapsApiKeyValid(),
  DEFAULT_REGION: {
    latitude: 0, // Fallback - will be overridden by Agency or GPS location
    longitude: 0,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  },
  ZOOM_LEVELS: {
    DEFAULT: 15,
    ROUTE_OVERVIEW: 13,
    STOP_DETAIL: 18,
  },
  UPDATE_INTERVAL: 5000, // 5 seconds
  BACKGROUND_UPDATE_INTERVAL: 30000, // 30 seconds
  /** How long the map vehicle info panel stays visible after tapping a vehicle arrow. */
  VEHICLE_INFO_WINDOW_DISMISS_MS: 10000,
};

